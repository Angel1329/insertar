

package ordenamientodatos;


public class OrdenamientoDatos {


    public static void main(String[] args) {
        new FrmDocumentos().setVisible(true);
    }
    
}
